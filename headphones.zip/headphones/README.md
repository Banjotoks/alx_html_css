# Headphones Landing Page

This is a simple landing page for a headphones company. It features a header with navigation links and a hero section with a call-to-action button.

## Features

- Responsive design
- Header with navigation links
- Hero section with a background image, headline, subheadline, and call-to-action button
- CSS variables for easy customization
- Mobile-friendly design

